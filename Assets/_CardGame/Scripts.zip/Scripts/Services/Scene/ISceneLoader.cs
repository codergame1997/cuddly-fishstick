public interface ISceneLoader
{
    void LoadScene(string sceneName);
    void LoadScene(int sceneIndex);
}