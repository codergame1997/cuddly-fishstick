public static class GameContext
{
    public static LayoutConfig SelectedLayout;
    public static bool IsLoadGame = false;
}