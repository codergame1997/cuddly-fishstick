public interface IAudioService
{
    void Play(SoundType type);
    void StopAll();
}