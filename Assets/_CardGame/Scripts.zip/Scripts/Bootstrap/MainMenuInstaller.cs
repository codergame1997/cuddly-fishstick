using Zenject;
using UnityEngine;

public class MainMenuInstaller : MonoInstaller<MainMenuInstaller>
{
    [SerializeField] private MainMenuView mainMenuView;
    [SerializeField] private LayoutDatabase layoutDatabase;

    public override void InstallBindings()
    {
        Container.Bind<SaveService>().AsSingle();

        Container.Bind<ISceneLoader>().To<SceneLoader>().AsSingle();

        Container.Bind<LayoutDatabase>().FromInstance(layoutDatabase).AsSingle();
        Container.Bind<MainMenuView>().FromInstance(mainMenuView).AsSingle();

        // Container.Bind<MainMenuPresenter>().AsSingle().NonLazy();
        Container.BindInterfacesAndSelfTo<MainMenuPresenter>().AsSingle().NonLazy();
    }
}