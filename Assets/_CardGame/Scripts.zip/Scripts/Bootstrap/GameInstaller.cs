using Zenject;
using UnityEngine;

public class GameInstaller : MonoInstaller<GameInstaller>
{
    [SerializeField] private BoardView boardView;
    [SerializeField] private PromptView promptView;
    [SerializeField] private GameplayMenuView gameplayMenuView;
    [SerializeField] private CardData[] cardPool;
    [SerializeField] private AudioService audioService;
    [SerializeField] private SoundDatabase soundDatabase;

    public override void InstallBindings()
    {
        // Core model & services (newed by Zenject)
        Container.BindInterfacesAndSelfTo<GameModel>().AsSingle();
        Container.BindInterfacesAndSelfTo<SaveService>().AsSingle();
        Container.BindInterfacesAndSelfTo<SceneLoader>().AsSingle();
        Container.BindInterfacesAndSelfTo<PromptService>().AsSingle();

        // Scene references
        Container.Bind<BoardView>().FromInstance(boardView).AsSingle();
        Container.Bind<PromptView>().FromInstance(promptView).AsSingle();
        Container.Bind<GameplayMenuView>().FromInstance(gameplayMenuView).AsSingle();
        Container.Bind<CardData[]>().FromInstance(cardPool).AsSingle();
        Container.Bind<AudioService>().FromInstance(audioService).AsSingle();
        Container.Bind<SoundDatabase>().FromInstance(soundDatabase).AsSingle();

        // Presenters
        Container.BindInterfacesAndSelfTo<GamePresenter>().AsSingle().NonLazy();
        Container.BindInterfacesAndSelfTo<GameplayMenuPresenter>().AsSingle().NonLazy();

        // Saving on pause/quit
        Container.BindInterfacesAndSelfTo<GameLifecycleHandler>().AsSingle().NonLazy();
    }
}